export interface BillionaireSlide {
  rank: number;
  name: string;
  cnName: string;
  title: string;
  company: string;
  netWorth: string;
  avatarUrl: string;
  description: string;
  lyrics: string;
  colorTheme: string; // Tailwind gradient or color values
  bgAccent: string;
}

export interface Coin {
  x: number;
  y: number;
  speed: number;
  size: number;
  rotation: number;
  rotationSpeed: number;
  type: 'coin' | 'dollar' | 'gold_bar' | 'doge' | 'g_particle';
}

export interface LyricLine {
  text: string;
  translation: string;
  timeSec: number;
}
