import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Search,
  Zap,
  DollarSign,
  TrendingUp,
  Database,
  Tv,
  Eye,
  Gift,
  Sparkles,
  Play,
  Share2,
  Package,
  Volume2,
  Rocket
} from 'lucide-react';
import { BillionaireSlide } from '../types';
import BillionaireAvatar from './BillionaireAvatar';
import AudioEngine from './AudioEngine';

interface InteractiveSlideProps {
  slide: BillionaireSlide;
  onSpawnParticles: (type: any, count: number, x?: number, y?: number) => void;
}

export const InteractiveSlide: React.FC<InteractiveSlideProps> = ({
  slide,
  onSpawnParticles,
}) => {
  const [isTriggered, setIsTriggered] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [googleStatus, setGoogleStatus] = useState('Idle');
  const [ballmerDanceLevel, setBallmerDanceLevel] = useState(0);
  const [isBlueScreenShattered, setIsBlueScreenShattered] = useState(false);
  const [buffettClicks, setBuffettClicks] = useState<number[]>([]);
  const [dbOpen, setDbOpen] = useState(false);
  const [droneCount, setDroneCount] = useState(0);
  const [champagneBubbles, setChampagneBubbles] = useState<{ id: number; left: number }[]>([]);
  const [rocketLauched, setRocketLaunched] = useState(false);

  // Trigger effect helper with resettimeout
  const triggerGeneralEffect = (duration = 800) => {
    setIsTriggered(true);
    setTimeout(() => setIsTriggered(false), duration);
  };

  // 10. Google Actions
  const handleGoogleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    setGoogleStatus('Searching');
    AudioEngine.playCoinSFX();
    onSpawnParticles('g_particle', 50, window.innerWidth / 2, window.innerHeight / 2);

    setTimeout(() => {
      setGoogleStatus('Exploded');
      onSpawnParticles('coin', 40, window.innerWidth / 2, window.innerHeight / 2);
      triggerGeneralEffect(1200);
    }, 450);
  };

  // 9. Ballmer Actions
  const handleBallmerDance = () => {
    setIsTriggered(true);
    setBallmerDanceLevel((prev) => prev + 1);
    AudioEngine.playCoinSFX();
    onSpawnParticles('coin', 15, window.innerWidth / 2, window.innerHeight * 0.4);

    // Speed up background flashes
    setTimeout(() => {
      setIsTriggered(false);
    }, 1800);
  };

  // 8. Bill Gates Shatter Actions
  const handleGlassShatter = () => {
    if (isBlueScreenShattered) {
      AudioEngine.playCoinSFX();
      onSpawnParticles('coin', 20);
      return;
    }
    AudioEngine.playGlassBreakSFX();
    setIsBlueScreenShattered(true);
    setIsTriggered(true);
    onSpawnParticles('coin', 80, window.innerWidth / 2, window.innerHeight / 2);
    setTimeout(() => setIsTriggered(false), 1500);
  };

  // 7. Buffett Soda Compounding Clicker
  const handleCokeClick = (e: React.MouseEvent) => {
    AudioEngine.playChimeSFX();
    setBuffettClicks((prev) => [...prev, Math.floor(Math.random() * 80) + 10]);
    onSpawnParticles('dollar', 15, e.clientX, e.clientY);
    triggerGeneralEffect(600);
  };

  // 6. Larry Ellison DB Pouring
  const handleEllisonDb = () => {
    setDbOpen(!dbOpen);
    AudioEngine.playChimeSFX();
    if (!dbOpen) {
      // Pour gold bars
      onSpawnParticles('gold_bar', 30, window.innerWidth / 2, window.innerHeight * 0.4);
      triggerGeneralEffect(1500);
    }
  };

  // 5. Zuckerberg VR Headset Tap
  const handleVRClick = () => {
    setIsTriggered(!isTriggered);
    AudioEngine.playCyberLaserSFX();
    if (!isTriggered) {
      onSpawnParticles('doge', 35, window.innerWidth / 2, window.innerHeight / 2);
    }
  };

  // 4. Jeff Bezos Unbox & drone flight unit
  const handleAmazonOpening = () => {
    AudioEngine.playChimeSFX();
    setDroneCount((prev) => prev + 2);
    onSpawnParticles('coin', 20, window.innerWidth / 2, window.innerHeight * 0.5);
    triggerGeneralEffect(1000);
  };

  // 3. Bernard Arnault luxury champagne bubbles
  const handleLuxuryClick = () => {
    AudioEngine.playChampagneSFX();
    triggerGeneralEffect(1500);
    // Add bubbles
    const newBubbles = Array.from({ length: 12 }).map((_, i) => ({
      id: Date.now() + i,
      left: Math.random() * 80 + 10,
    }));
    setChampagneBubbles((prev) => [...prev, ...newBubbles]);
    onSpawnParticles('coin', 15, window.innerWidth / 2, window.innerHeight * 0.4);

    setTimeout(() => {
      setChampagneBubbles((prev) => prev.filter((b) => !newBubbles.includes(b)));
    }, 3000);
  };

  // 1/2. Musk Space launch rocket
  const handleRocketLaunch = () => {
    if (rocketLauched) return;
    setRocketLaunched(true);
    AudioEngine.playRocketSFX();

    setTimeout(() => {
      // Boom! Sparkle canvas
      AudioEngine.playGlassBreakSFX();
      onSpawnParticles('gold_bar', 40, window.innerWidth / 2, 80);
      onSpawnParticles('coin', 80, window.innerWidth / 2, 80);
      triggerGeneralEffect(2000);
    }, 1200);

    setTimeout(() => {
      setRocketLaunched(false);
    }, 3500);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center w-full max-w-6xl mx-auto px-4 z-20">
      {/* LEFT SECTION: Visual Representation & Custom Game Canvas */}
      <div className="lg:col-span-6 flex flex-col items-center justify-center relative min-h-[360px] lg:min-h-[450px]">
        {/* Render individual mini interactive boxes behind or above the avatar */}

        {/* GOOGLE CLOUD MINIGAME BACKDROP */}
        {slide.avatarUrl === 'google' && (
          <div className="absolute inset-0 flex flex-col justify-end items-center pb-2 z-30">
            <form onSubmit={handleGoogleSubmit} className="w-full max-w-sm glass-panel p-3 rounded-full flex items-center shadow-lg border-blue-500/30 gap-2 mb-6">
              <Search className="text-blue-400 w-5 h-5 ml-2 shrink-0 animate-pulse" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Type here to search for fortune..."
                className="bg-transparent text-white font-mono text-xs outline-none flex-1 placeholder-slate-400"
              />
              <button
                type="submit"
                className="bg-gradient-to-r from-blue-500 to-green-500 hover:from-blue-600 hover:to-green-600 text-white font-display text-xs px-4 py-2.5 rounded-full transition-all duration-300 font-bold glow-btn shrink-0 cursor-pointer"
              >
                {googleStatus === 'Searching' ? 'SCANNING...' : 'FORTUNE'}
              </button>
            </form>
            <p className="text-[10px] font-mono text-slate-400 text-center animate-bounce">
              💡 Press enter/search to spray golden 'G' letters!
            </p>
          </div>
        )}

        {/* STEVE BALLMER DANCE CONTROLS */}
        {slide.avatarUrl === 'ballmer' && (
          <div className="absolute inset-0 flex flex-col justify-end items-center pb-2 z-30">
            <button
              onClick={handleBallmerDance}
              className="bg-gradient-to-r from-orange-500 to-yellow-500 hover:scale-105 active:scale-95 text-slate-900 font-display font-black text-xs px-6 py-3 rounded-xl transition-all duration-300 shadow-xl border-2 border-white cursor-pointer"
            >
              🔥 HYPE CLAP BEAT! ({ballmerDanceLevel})
            </button>
            <p className="text-[10px] font-mono text-orange-300 tracking-wider text-center pt-2 animate-bounce">
              Make Steve sweat gold! Overheat the pitch!
            </p>
          </div>
        )}

        {/* BILL GATES BLUE SCREEN OF FORTUNE */}
        {slide.avatarUrl === 'gates' && !isBlueScreenShattered && (
          <motion.div
            onClick={handleGlassShatter}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="absolute inset-0 bg-blue-700 border-4 border-blue-100 p-6 rounded-2xl font-mono text-left cursor-crosshair z-30 shadow-2xl flex flex-col justify-between overflow-hidden"
          >
            <div>
              <div className="bg-white text-blue-700 px-3 py-1 font-bold inline-block mb-3">SYSTEM EXCEPTION</div>
              <p className="text-xs text-blue-100 leading-relaxed pt-2">
                A serious fortune leak has occurred at address 0x999_MONEY_BACK_HOME.
              </p>
              <p className="text-[11px] text-blue-200 mt-4 font-bold border-l-2 border-blue-300 pl-2">
                * ERROR_CODE: TOO_MUCH_MONEY<br />
                * CURRENT_ASSETS: CRITICAL_OVERFLOW<br />
                * SUGGESTED_ACTION: SHATTER WINDOWS TO UNLOCK GOLD
              </p>
            </div>
            <div className="text-center text-xs animate-pulse text-white font-bold bg-blue-900/60 py-2 rounded">
              👉 CLICK TO SHATTER SCREEN OF DEATH 👈
            </div>
          </motion.div>
        )}

        {/* BUFFETT CASH COMPOUND STOCK GRAPH */}
        {slide.avatarUrl === 'buffett' && (
          <div className="absolute inset-x-0 bottom-1 flex flex-col items-center z-30">
            <div className="w-full h-16 flex items-end justify-center gap-1.5 px-4">
              {buffettClicks.map((height, idx) => (
                <motion.div
                  key={idx}
                  initial={{ height: 0 }}
                  animate={{ height: `${height}%` }}
                  className="w-4 bg-gradient-to-t from-emerald-600 to-green-400 border-x border-t border-green-300 rounded-t"
                  transition={{ type: 'spring', stiffness: 200 }}
                />
              ))}
            </div>
            <button
              onClick={handleCokeClick}
              className="bg-red-600 hover:bg-red-700 text-white font-display font-medium text-xs px-4 py-2.5 rounded-full shadow-lg border border-red-400 flex items-center gap-2 mt-2 cursor-pointer"
            >
              🥤 Tap Coke to Invest
            </button>
          </div>
        )}

        {/* ORACLE DB VAULT */}
        {slide.avatarUrl === 'ellison' && (
          <div className="absolute inset-0 flex flex-col justify-end items-center pb-2 z-30">
            <div className="flex gap-4 mb-4">
              <div className={`w-8 h-8 rounded-full border-2 ${dbOpen ? 'bg-red-500 border-red-300 animate-pulse' : 'bg-slate-700 border-slate-500'}`} />
              <div className={`w-8 h-8 rounded-full border-2 ${dbOpen ? 'bg-green-500 border-green-300 animate-pulse' : 'bg-slate-700 border-slate-500'}`} />
            </div>
            <button
              onClick={handleEllisonDb}
              className="bg-stone-800 hover:bg-stone-700 text-yellow-400 font-mono text-xs px-5 py-3 rounded-lg border border-yellow-600 font-bold glow-btn uppercase tracking-wider cursor-pointer"
            >
              💾 {dbOpen ? 'CLOSE SERVER VAULT' : 'DUMP ORACLE GOLD BRICKS!'}
            </button>
          </div>
        )}

        {/* ZUCK VR MATRIX STREAM */}
        {slide.avatarUrl === 'zuckerberg' && (
          <div className="absolute inset-0 flex flex-col justify-end items-center pb-2 z-30">
            <button
              onClick={handleVRClick}
              className="bg-purple-900/80 hover:bg-purple-800 text-purple-300 font-mono text-xs px-5 py-2.5 rounded-full border-2 border-purple-400 tracking-wider flex items-center gap-2 cursor-pointer"
            >
              <Eye className="w-4 h-4 text-purple-400" /> {isTriggered ? 'VR MATRIX ACTIVATED' : 'TAP VR GLASSES FOR MATRIX'}
            </button>
          </div>
        )}

        {/* BEZOS DRONE CONTROL COIN HAULING */}
        {slide.avatarUrl === 'bezos' && (
          <div className="absolute inset-0 flex flex-col justify-end items-center pb-2 z-30">
            {droneCount > 0 && (
              <div className="absolute top-4 inset-x-0 flex justify-around pointer-events-none">
                {Array.from({ length: Math.min(droneCount, 6) }).map((_, i) => (
                  <motion.div
                    key={i}
                    animate={{
                      y: [0, -12, 0],
                      x: [0, Math.sin(i) * 15, 0],
                    }}
                    transition={{ duration: 2.5, repeat: Infinity, delay: i * 0.3 }}
                    className="bg-slate-800 border border-amber-500 rounded p-1.5 flex items-center gap-1 shadow"
                  >
                    <Package className="w-3.5 h-3.5 text-amber-500 animate-bounce" />
                    <span className="text-[9px] font-mono text-white">$100B</span>
                  </motion.div>
                ))}
              </div>
            )}
            <button
              onClick={handleAmazonOpening}
              className="bg-amber-500 hover:bg-amber-600 text-slate-900 font-display font-black text-xs px-5 py-2.5 rounded shadow-lg flex items-center gap-2 cursor-pointer"
            >
              <Gift className="w-4 h-4" /> DISPATCH DRONE DELIVERIES ({droneCount})
            </button>
          </div>
        )}

        {/* ARNAULT LUXURY CHAMPAGNE POPPING */}
        {slide.avatarUrl === 'arnault' && (
          <div className="absolute inset-0 flex flex-col justify-end items-center pb-2 z-30">
            {champagneBubbles.length > 0 && (
              <div className="absolute inset-x-4 top-4 bottom-20 overflow-hidden pointer-events-none">
                {champagneBubbles.map((bubble) => (
                  <motion.div
                    key={bubble.id}
                    initial={{ y: 250, opacity: 0.9, scale: 0.5 }}
                    animate={{ y: -50, opacity: 0, scale: [0.5, 1.2, 0.8] }}
                    transition={{ duration: 2.5, ease: 'easeOut' }}
                    style={{ left: `${bubble.left}%` }}
                    className="absolute w-5 h-5 rounded-full border border-yellow-300 bg-yellow-400/20 shadow-[0_0_10px_#f59e0b]"
                  />
                ))}
              </div>
            )}
            <button
              onClick={handleLuxuryClick}
              className="bg-stone-900 border border-stone-600 text-stone-200 hover:bg-stone-800 font-serif text-xs px-5 py-2.5 rounded uppercase tracking-widest cursor-pointer"
            >
              🍾 Pop Premium champagne
            </button>
          </div>
        )}

        {/* ELON MUSK SPACEX ROCKET LAUNCHER */}
        {slide.avatarUrl === 'musk' && (
          <div className="absolute inset-0 flex flex-col justify-end items-center pb-2 z-30">
            {/* SpaceX Rocket model */}
            <motion.div
              animate={
                rocketLauched
                  ? {
                      y: [0, -450],
                      scale: [1, 1.3, 0.4],
                      opacity: [1, 1, 0],
                      transition: { duration: 1.5, ease: 'easeIn' },
                    }
                  : { y: 0 }
              }
              className="absolute bottom-20 pointer-events-none"
            >
              <Rocket className="w-12 h-12 text-pink-500 drop-shadow-[0_0_12px_#d946ef] rotate-0" />
              {rocketLauched && (
                <div className="w-2 h-8 bg-gradient-to-t from-orange-500 via-yellow-400 to-transparent mx-auto mt-1 animate-pulse" />
              )}
            </motion.div>

            <button
              onClick={handleRocketLaunch}
              disabled={rocketLauched}
              className={`${rocketLauched ? 'bg-fuchsia-950 border-fuchsia-800 text-fuchsia-500' : 'bg-fuchsia-700 hover:bg-fuchsia-600 border-fuchsia-500 text-white'} border-2 px-6 py-3 rounded-full font-display font-black text-xs tracking-widest glow-btn uppercase cursor-pointer flex items-center gap-2`}
            >
              🚀 {rocketLauched ? 'BLASTING OFF TO MARS!' : 'LAUNCH FALCON HEAVY!'}
            </button>
          </div>
        )}

        {/* Main Billionaire Avatar Caricature */}
        <BillionaireAvatar
          type={slide.avatarUrl}
          isTriggered={isTriggered || slide.avatarUrl === 'ballmer' && ballmerDanceLevel > 0}
          className="w-56 h-56 lg:w-68 lg:h-68 mb-12"
          onClick={() => {
            // General avatar click: drop gold ambient coins
            AudioEngine.playCoinSFX();
            onSpawnParticles('coin', 15);
            triggerGeneralEffect(600);
          }}
        />
      </div>

      {/* RIGHT SECTION: Info Cards & Bilingual Karaoke Lyrics */}
      <div className="lg:col-span-6 text-left flex flex-col justify-center space-y-6">
        <div className="flex items-center gap-4">
          <span className="font-display font-black text-6xl lg:text-8xl gold-text select-none leading-none drop-shadow-md">
            #{slide.rank === 12 ? '2/1' : slide.rank}
          </span>
          <div>
            <span className="text-[10px] font-mono tracking-widest text-[#FFD700] bg-yellow-500/10 border border-[#FFD700]/30 px-3 py-1 rounded-full uppercase font-bold inline-block">
              {slide.company}
            </span>
            <h2 className="font-display font-black text-3xl lg:text-4xl text-white mt-2 leading-none uppercase tracking-wide">
              {slide.name}
            </h2>
            <p className="text-xs text-slate-400 font-sans font-semibold tracking-wider mt-1">
              {slide.cnName} • {slide.title}
            </p>
          </div>
        </div>

        {/* Wealth Indicator Card */}
        <div className="glass p-6 rounded-2xl border-white/10 shadow-2xl relative overflow-hidden bg-black/60">
          <div className="absolute right-4 top-4">
            <DollarSign className="w-12 h-12 text-[#FFD700]/10" />
          </div>
          <span className="text-[10px] font-mono text-[#FFD700] tracking-widest font-black block uppercase">
            ESTIMATED NET WORTH
          </span>
          <span className="font-display font-black text-4xl text-[#FFD700] block mt-1 tracking-tight">
            {slide.netWorth}
          </span>
          <p className="text-sm text-slate-300 leading-relaxed mt-4 font-sans font-medium">
            {slide.description}
          </p>
        </div>

        {/* Storyboard Lyrics Box */}
        <div className="border-l-4 border-[#FFD700] pl-5 py-3 bg-white/[0.02] border-yellow-500/20 rounded-r-2xl">
          <span className="text-[9px] font-mono text-[#FFD700] font-black block tracking-widest uppercase">
            🎵 MV SUBTITLE (KARAOKE) 🎵
          </span>
          <p className="font-display font-extrabold text-white text-lg tracking-wide leading-relaxed mt-1.5">
            {slide.lyrics.split('\n')[0]}
          </p>
          <p className="font-mono text-xs text-amber-300 mt-1.5 tracking-wider opacity-90">
            {slide.lyrics.split('\n')[1] || ''}
          </p>
        </div>

        {/* Action Suggestion Indicator */}
        <div className="flex items-center gap-2 text-[10px] font-mono text-slate-500 pt-3 border-t border-white/10">
          <Zap className="w-3.5 h-3.5 text-[#FFD700] animate-pulse shrink-0" />
          <span>Click on the caricature or use the special triggers to extract dollar drops!</span>
        </div>
      </div>
    </div>
  );
};

export default InteractiveSlide;
