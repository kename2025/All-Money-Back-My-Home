import React, { useEffect, useRef, useImperativeHandle, forwardRef } from 'react';
import { Coin } from '../types';

export interface CoinCanvasRef {
  spawnParticles: (
    type: Coin['type'],
    count: number,
    startX?: number,
    startY?: number
  ) => void;
  clearParticles: () => void;
}

interface CoinCanvasProps {
  intensity?: number; // fallback ambient drift intensity
  activeRank?: number;
}

export const CoinCanvas = forwardRef<CoinCanvasRef, CoinCanvasProps>(
  ({ intensity = 15, activeRank }, ref) => {
    const canvasRef = useRef<HTMLCanvasElement | null>(null);
    const coinsRef = useRef<Coin[]>([]);
    const animationFrameRef = useRef<number | null>(null);
    const containerRef = useRef<HTMLDivElement | null>(null);

    // Initial and responsive canvas sizing with ResizeObserver
    useEffect(() => {
      const canvas = canvasRef.current;
      if (!canvas) return;

      const handleResize = (entries: ResizeObserverEntry[]) => {
        for (let entry of entries) {
          const { width, height } = entry.contentRect;
          canvas.width = width;
          canvas.height = height;
        }
      };

      const resizeObserver = new ResizeObserver(handleResize);
      if (canvas.parentElement) {
        resizeObserver.observe(canvas.parentElement);
      }

      return () => {
        resizeObserver.disconnect();
      };
    }, []);

    // Create a particle
    const createParticle = (
      type: Coin['type'] = 'coin',
      customX?: number,
      customY?: number,
      speedMultiplier = 1
    ): Coin => {
      const width = canvasRef.current?.width || window.innerWidth;
      const initialY = customY !== undefined ? customY : -30;
      const initialX = customX !== undefined ? customX : Math.random() * width;

      // Type-specific sizes & speeds
      let size = Math.random() * 12 + 10;
      let speed = (Math.random() * 3 + 2.5) * speedMultiplier;

      if (type === 'gold_bar') {
        size = Math.random() * 15 + 16;
        speed = (Math.random() * 4 + 4) * speedMultiplier;
      } else if (type === 'doge') {
        size = Math.random() * 14 + 11;
        speed = (Math.random() * 2 + 2) * speedMultiplier;
      } else if (type === 'g_particle') {
        size = Math.random() * 8 + 8;
        speed = (Math.random() * 5 + 3) * speedMultiplier;
      }

      return {
        x: initialX,
        y: initialY,
        speed,
        size,
        rotation: Math.random() * Math.PI * 2,
        rotationSpeed: (Math.random() - 0.5) * 0.1,
        type,
      };
    };

    // Imperative exposure to parent controls
    useImperativeHandle(ref, () => ({
      spawnParticles: (type, count, startX, startY) => {
        const width = canvasRef.current?.width || window.innerWidth;
        const x = startX !== undefined ? startX : Math.random() * width;
        const y = startY !== undefined ? startY : -20;

        for (let i = 0; i < count; i++) {
          // Spray outwards slightly for explosive effect
          const p = createParticle(type, x, y, 1.5);
          // Distort horizontal velocity for exploded items
          if (startX !== undefined) {
            (p as any).vx = (Math.random() - 0.5) * 12;
            (p as any).vy = -(Math.random() * 8 + 4); // fly up first
          }
          coinsRef.current.push(p);
        }
      },
      clearParticles: () => {
        coinsRef.current = [];
      },
    }));

    // Particle logic core update/draw loop
    useEffect(() => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const draw = () => {
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        // Keep a minimum steady ambient backdrop particles depending on rank
        let targetLimit = intensity;
        let ambientType: Coin['type'] = 'coin';

        // Contextual rain depending on active slides
        if (activeRank === 12) {
          targetLimit = 75; // Climax gold rain
        } else if (activeRank === 7) {
          targetLimit = 35;
          ambientType = 'dollar'; // Buffett's dollar bills loop
        } else if (activeRank === 5) {
          targetLimit = 25;
          ambientType = 'doge'; // Cyber Zuck Dogecoins
        }

        while (coinsRef.current.length < targetLimit) {
          coinsRef.current.push(createParticle(ambientType));
        }

        coinsRef.current.forEach((coin, index) => {
          // If custom exploding physics properties exist
          if ((coin as any).vx !== undefined) {
            coin.x += (coin as any).vx;
            coin.y += (coin as any).vy;
            (coin as any).vy += 0.25; // gravity
            (coin as any).vx *= 0.98; // air resistance
          } else {
            coin.y += coin.speed;
            // Slight slide sway
            coin.x += Math.sin(coin.y / 30) * 0.4;
          }

          coin.rotation += coin.rotationSpeed;

          ctx.save();
          ctx.translate(coin.x, coin.y);
          ctx.rotate(coin.rotation);

          // Render depending on customization type
          if (coin.type === 'coin') {
            // Gold coin
            ctx.beginPath();
            ctx.arc(0, 0, coin.size, 0, Math.PI * 2);
            const grad = ctx.createRadialGradient(-3, -3, 1, 0, 0, coin.size);
            grad.addColorStop(0, '#FFE875');
            grad.addColorStop(0.8, '#F5B000');
            grad.addColorStop(1, '#B87A00');
            ctx.fillStyle = grad;
            ctx.fill();

            // Inner coin details
            ctx.strokeStyle = '#FFFFFF80';
            ctx.lineWidth = 1;
            ctx.stroke();

            ctx.beginPath();
            ctx.arc(0, 0, coin.size * 0.6, 0, Math.PI * 2);
            ctx.strokeStyle = '#B87A0080';
            ctx.stroke();

            // Inner center '$'
            ctx.fillStyle = '#D4AF37';
            ctx.font = `bold ${coin.size * 0.8}px Inter`;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('$', 0, 0);

          } else if (coin.type === 'dollar') {
            // Green paper note
            const w = coin.size * 2;
            const h = coin.size * 1.0;

            ctx.fillStyle = '#22C55E';
            ctx.fillRect(-w / 2, -h / 2, w, h);

            // Bill trim inner
            ctx.strokeStyle = '#15803D';
            ctx.lineWidth = 1.5;
            ctx.strokeRect(-w / 2 + 2, -h / 2 + 2, w - 4, h - 4);

            // Dollar logo center
            ctx.beginPath();
            ctx.arc(0, 0, h * 0.35, 0, Math.PI * 2);
            ctx.fillStyle = '#DCFCE7';
            ctx.fill();

            ctx.fillStyle = '#166534';
            ctx.font = `bold ${h * 0.5}px share-tech-mono`;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('$', 0, 0);

          } else if (coin.type === 'gold_bar') {
            // Gold brick box
            const w = coin.size * 1.8;
            const h = coin.size * 0.8;

            // Gradient for metallic look
            const mGrad = ctx.createLinearGradient(-w / 2, -h / 2, w / 2, h / 2);
            mGrad.addColorStop(0, '#FFF59D');
            mGrad.addColorStop(0.3, '#FBC02D');
            mGrad.addColorStop(0.7, '#F57F17');
            mGrad.addColorStop(1, '#9E6A00');

            ctx.fillStyle = mGrad;
            ctx.beginPath();
            ctx.moveTo(-w / 2, -h / 2);
            ctx.lineTo(w / 2, -h / 2 * 0.7);
            ctx.lineTo(w / 2, h / 2);
            ctx.lineTo(-w / 2, h / 2);
            ctx.closePath();
            ctx.fill();

            // Highlight border
            ctx.strokeStyle = '#FFFFFF60';
            ctx.lineWidth = 1;
            ctx.stroke();

            // stamp
            ctx.fillStyle = '#6D4C41';
            ctx.font = `bold ${h * 0.4}px monospace`;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('999.9', 0, 0);

          } else if (coin.type === 'doge') {
            // Dogecoin holographic
            ctx.beginPath();
            ctx.arc(0, 0, coin.size, 0, Math.PI * 2);
            const dGrad = ctx.createRadialGradient(-2, -2, 1, 0, 0, coin.size);
            dGrad.addColorStop(0, '#E9D5FF');
            dGrad.addColorStop(0.5, '#C084FC');
            dGrad.addColorStop(1, '#6B21A8');
            ctx.fillStyle = dGrad;
            ctx.fill();

            ctx.strokeStyle = '#FFFFFFB0';
            ctx.lineWidth = 1.2;
            ctx.stroke();

            // Doge D character
            ctx.fillStyle = '#FFFFFF';
            ctx.font = `black ${coin.size * 1.0}px sans-serif`;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('Ð', 0, 2);

          } else if (coin.type === 'g_particle') {
            // Colorful G particles (Google vibe)
            const colors = ['#4285F4', '#EA4335', '#FBBC05', '#34A853'];
            const colorIndex = Math.floor(Math.abs(coin.x)) % colors.length;

            ctx.beginPath();
            ctx.arc(0, 0, coin.size, 0, Math.PI * 2);
            ctx.fillStyle = colors[colorIndex];
            ctx.fill();

            // Subtle inner luster
            ctx.fillStyle = '#FFFFFFBF';
            ctx.font = `bold ${coin.size * 1.1}px Inter`;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('G', 0, 0);
          }

          ctx.restore();

          // Out-of-bounds cleanup
          if (coin.y > canvas.height + 40 || coin.x < -40 || coin.x > canvas.width + 40) {
            coinsRef.current[index] = createParticle(ambientType);
          }
        });

        animationFrameRef.current = requestAnimationFrame(draw);
      };

      draw();

      return () => {
        if (animationFrameRef.current) {
          cancelAnimationFrame(animationFrameRef.current);
        }
      };
    }, [intensity, activeRank]);

    return (
      <div ref={containerRef} className="absolute inset-0 pointer-events-none z-10 w-full h-full overflow-hidden">
        <canvas
          ref={canvasRef}
          id="coinCanvas"
          style={{ display: 'block' }}
          className="w-full h-full"
        />
      </div>
    );
  }
);

CoinCanvas.displayName = 'CoinCanvas';
export default CoinCanvas;
