import React from 'react';
import { motion } from 'motion/react';
import { 
  Sparkles, 
  Terminal, 
  Coins, 
  DollarSign, 
  Search, 
  Tv, 
  Award,
  Zap
} from 'lucide-react';

import avatarGoogle from '../assets/images/avatar_google_1780710185790.png';
import avatarBallmer from '../assets/images/avatar_ballmer_1780710201379.png';
import avatarGates from '../assets/images/avatar_gates_1780710212604.png';
import avatarBuffett from '../assets/images/avatar_buffett_1780710163492.png';
import avatarEllison from '../assets/images/avatar_ellison_1780710225323.png';
import avatarZuckerberg from '../assets/images/avatar_zuckerberg_1780710237373.png';
import avatarBezos from '../assets/images/avatar_bezos_1780710250702.png';
import avatarArnault from '../assets/images/avatar_arnault_1780710261989.png';
import avatarMusk from '../assets/images/avatar_musk_1780710272613.png';

const IMAGE_MAP: Record<string, string> = {
  google: avatarGoogle,
  ballmer: avatarBallmer,
  gates: avatarGates,
  buffett: avatarBuffett,
  ellison: avatarEllison,
  zuckerberg: avatarZuckerberg,
  bezos: avatarBezos,
  arnault: avatarArnault,
  musk: avatarMusk,
};

interface AvatarProps {
  type: string;
  isTriggered: boolean;
  className?: string;
  onClick?: () => void;
}

export const BillionaireAvatar: React.FC<AvatarProps> = ({
  type,
  isTriggered,
  className = 'w-48 h-48',
  onClick,
}) => {
  const shakeAnimation = {
    animate: isTriggered
      ? {
          x: [0, -12, 12, -12, 12, -8, 8, -4, 4, 0],
          y: [0, 8, -8, 8, -8, 4, -4, 2, -2, 0],
          rotate: [0, -4, 4, -4, 4, -2, 2, 0],
          transition: { duration: 0.6, repeat: Infinity }
        }
      : {},
  };

  const idleMotion = {
    animate: {
      y: [0, -6, 0],
      transition: {
        duration: 4,
        repeat: Infinity,
        ease: "easeInOut",
      },
    },
  };

  const currentImgSrc = IMAGE_MAP[type] || avatarMusk;

  return (
    <motion.div
      className={`relative cursor-pointer select-none ${className} flex items-center justify-center`}
      variants={type === 'ballmer' ? shakeAnimation : idleMotion}
      animate="animate"
      onClick={onClick}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
    >
      {/* Outer spinning gold orbits when triggered */}
      {isTriggered && (
        <div className="absolute inset-[-12px] rounded-full border-2 border-dashed border-[#FFD700]/60 animate-spin z-0 pointer-events-none" style={{ animationDuration: '8s' }} />
      )}

      {/* Outer ambient glow based on type */}
      <div className={`absolute inset-0 rounded-full blur-2xl opacity-40 mix-blend-screen transition-all duration-500 z-0 ${
        isTriggered ? 'scale-110 opacity-75' : 'scale-95'
      } ${
        type === 'musk' ? 'bg-fuchsia-500/40' :
        type === 'gates' ? 'bg-cyan-500/40' :
        type === 'buffett' ? 'bg-emerald-500/40' :
        type === 'zuckerberg' ? 'bg-indigo-500/40' :
        type === 'bezos' ? 'bg-yellow-500/40' :
        type === 'arnault' ? 'bg-neutral-500/40' : 'bg-[#FFD700]/30'
      }`} />

      {/* Main Circular Profile Card */}
      <div className="relative w-full h-full rounded-full p-1 bg-gradient-to-br from-[#FFD700] via-[#B8860B]/40 to-white/10 shadow-[0_0_30px_rgba(255,215,0,0.15)] overflow-hidden z-10 flex items-center justify-center">
        {/* Inner black face background */}
        <div className="w-full h-full rounded-full bg-black relative overflow-hidden flex items-center justify-center">
          
          {/* Main Photorealistic Portrait Image */}
          <img
            src={currentImgSrc}
            alt={type}
            className={`w-full h-full object-cover transition-transform duration-500 ${
              isTriggered ? 'scale-110 contrast-[1.1]' : 'scale-100'
            }`}
            referrerPolicy="no-referrer"
          />

          {/* DYNAMIC INTERACTIVE VISUAL OVERLAYS */}
          
          {/* Google Founders (Larry & Sergey Brin) Sparkles */}
          {type === 'google' && isTriggered && (
            <div className="absolute inset-x-0 bottom-4 flex justify-center gap-1 bg-black/70 py-1 px-3.5 rounded-full border border-blue-500/30">
              <Search className="w-3.5 h-3.5 text-blue-400 animate-pulse" />
              <span className="text-[9px] font-mono font-black text-white tracking-wider animate-bounce">PAGERANK DETECTED</span>
            </div>
          )}

          {/* Steve Ballmer Red Crazy Sweatband & Developers text */}
          {type === 'ballmer' && (
            <div className="absolute inset-0 pointer-events-none flex flex-col justify-between items-center py-4">
              {/* Crazy red sweatband */}
              <div className={`transition-all duration-300 w-11/12 py-1 px-2 text-[9px] font-mono leading-none bg-[#EF4444] text-white border border-[#FEE2E2]/20 font-black shadow-lg rounded text-center uppercase tracking-widest ${
                isTriggered ? 'scale-105 bg-red-600 animate-pulse border-white/50' : 'opacity-80'
              }`}>
                DEVELOPERS!
              </div>
              {isTriggered && (
                <div className="w-full text-center text-[10px] font-mono font-black text-yellow-300 bg-black/80 py-1 uppercase tracking-widest border-t border-yellow-500/20">
                  ⚡️ HYPED UP ⚡️
                </div>
              )}
            </div>
          )}

          {/* Bill Gates Retro Blue Screen Error & Floppy disk */}
          {type === 'gates' && (
            <div className="absolute inset-0 pointer-events-none flex flex-col justify-between items-center py-4">
              {isTriggered ? (
                <>
                  <div className="absolute inset-0 bg-[#3B82F6]/30 backdrop-blur-[1px] flex flex-col items-center justify-center text-center p-3 animate-pulse">
                    <span className="font-mono text-[9px] leading-tight text-white bg-blue-700 px-1 border border-white/20">FATAL_ERROR: 0x80070005</span>
                    <span className="font-mono text-[8px] leading-tight text-yellow-300 mt-1 uppercase font-bold">GOLDEN RAIN CRASH</span>
                  </div>
                  <Terminal className="w-6 h-6 text-white absolute bottom-4 animate-bounce" />
                </>
              ) : (
                <span className="text-[8px] font-mono text-cyan-400 border border-cyan-500/20 px-2 py-0.5 rounded bg-black/60 tracking-wider">
                  MICROSOFT_DOS
                </span>
              )}
            </div>
          )}

          {/* Warren Buffett Cherry Coke overlay and compounding graph */}
          {type === 'buffett' && isTriggered && (
            <div className="absolute inset-0 pointer-events-none bg-emerald-950/20 flex flex-col items-center justify-center">
              <div className="bg-black/80 px-2 py-1 border border-emerald-500/30 rounded flex items-center gap-1 animate-bounce">
                <Coins className="w-3.5 h-3.5 text-emerald-400 animate-spin" />
                <span className="text-[9px] font-mono text-[#FFD700] font-black">COMPOUND_INTEREST</span>
              </div>
            </div>
          )}

          {/* Larry Ellison Luxury Yacht Captain Shades and clouds */}
          {type === 'ellison' && (
            <div className="absolute inset-0 pointer-events-none flex flex-col justify-end items-center pb-4">
              {isTriggered ? (
                <div className="bg-black/80 border border-rose-500/30 px-3 py-1 rounded text-center animate-bounce">
                  <span className="text-[9px] font-mono font-black text-rose-400 uppercase tracking-widest">CLOUDBANK ACTIVE</span>
                </div>
              ) : (
                <span className="text-[8px] font-mono text-rose-400 border border-rose-500/20 px-2 py-0.5 rounded bg-black/60 tracking-wider">
                  ORACLE_CLOUD
                </span>
              )}
            </div>
          )}

          {/* Mark Zuckerberg Glowing VR Goggles headset */}
          {type === 'zuckerberg' && (
            <div className="absolute inset-0 pointer-events-none flex flex-col justify-center items-center p-3">
              {/* Virtual Reality Visor Overlay */}
              <div className={`transition-all duration-300 px-3 py-1.5 rounded-lg border flex flex-col items-center justify-center w-4/5 text-center bg-indigo-950/90 ${
                isTriggered 
                  ? 'border-indigo-400 shadow-[0_0_15px_rgba(139,92,246,0.5)] scale-105' 
                  : 'border-white/10 opacity-70 scale-95'
              }`}>
                <span className="text-[7.5px] font-mono tracking-widest text-[#FFD700] font-black uppercase">METAVERSE VISOR</span>
                <span className="text-[10px] font-mono font-black text-white mt-0.5 tracking-tight">
                  {isTriggered ? 'VR_STREAMING' : 'READY TO STREAM'}
                </span>
              </div>
            </div>
          )}

          {/* Jeff Bezos Laser Eyes beaming out */}
          {type === 'bezos' && (
            <div className="absolute inset-0 pointer-events-none flex flex-col items-center justify-between py-4">
              {isTriggered ? (
                <>
                  {/* Outer laser splash overlay */}
                  <div className="absolute inset-0 bg-amber-500/10 mix-blend-overlay animate-pulse" />
                  
                  {/* Glowing Laser eye markers positioned roughly over Jeff's eyes */}
                  <div className="absolute top-[38%] left-[38%] w-3 h-3 bg-red-500 rounded-full blur-[2px] animate-ping" />
                  <div className="absolute top-[38%] left-[54%] w-3 h-3 bg-red-500 rounded-full blur-[2px] animate-ping" />
                  
                  <div className="bg-black/90 px-3 py-1 border border-red-500/30 rounded-xl text-center flex items-center gap-1.5 pb-1 select-none animate-bounce mt-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-ping" />
                    <span className="text-[8px] font-mono text-red-500 font-extrabold tracking-widest">DRONE LASERS ARMED</span>
                  </div>
                </>
              ) : (
                <span className="text-[8px] font-mono text-amber-500 border border-amber-500/20 px-2 py-0.5 rounded bg-black/60 tracking-wider">
                  AMAZON_PRIME
                </span>
              )}
            </div>
          )}

          {/* Bernard Arnault Royal Gold Monocle & Champagne */}
          {type === 'arnault' && (
            <div className="absolute inset-0 pointer-events-none flex flex-col justify-between items-center py-4">
              {isTriggered ? (
                <>
                  {/* Monocle glass ripple glow */}
                  <div className="absolute top-[40%] left-[34%] w-10 h-10 rounded-full border-2 border-yellow-400 bg-yellow-400/10 animate-pulse shadow-[0_0_15px_rgba(251,191,36,0.6)]" />
                  <div className="bg-black/80 px-2.5 py-1 border border-yellow-500/30 rounded-full text-center mt-2 flex items-center gap-1 animate-bounce">
                    <Sparkles className="w-3 h-3 text-yellow-400 animate-spin" />
                    <span className="text-[8px] font-mono text-[#FFD700] font-black uppercase tracking-wider">CHAMPAGNE POPPED</span>
                  </div>
                </>
              ) : (
                <span className="text-[8px] font-mono text-zinc-400 border border-white/10 px-2 py-0.5 rounded bg-black/60 tracking-wider">
                  LVMH_LUXURY
                </span>
              )}
            </div>
          )}

          {/* Elon Musk Space Visor Helmet Overlay */}
          {type === 'musk' && (
            <div className="absolute inset-0 pointer-events-none flex flex-col justify-end items-center pb-4">
              {isTriggered ? (
                <div className="absolute inset-0 bg-fuchsia-950/45 border-2 border-fuchsia-500/40 rounded-full p-4 flex flex-col items-center justify-between text-center backdrop-blur-[0.5px]">
                  <div className="bg-fuchsia-600/90 text-white font-mono text-[8.5px] font-black py-0.5 px-2 rounded-full shadow border border-white/20 uppercase tracking-widest animate-pulse">
                    🚀 SPACEWALK
                  </div>
                  <div className="bg-black/90 border border-fuchsia-400/30 px-3 py-1 rounded text-[9.5px] font-mono font-black text-fuchsia-400 uppercase tracking-widest animate-bounce">
                    MARS COLONY: ON Track
                  </div>
                </div>
              ) : (
                <span className="text-[8px] font-mono text-fuchsia-400 border border-fuchsia-500/20 px-2 py-0.5 rounded bg-black/60 tracking-wider">
                  SPACEX_FALCON
                </span>
              )}
            </div>
          )}

          {/* Sparkles / Gold drops on Click indicator */}
          {isTriggered && (
            <div className="absolute top-2 right-2 animate-ping">
              <Sparkles className="w-4 h-4 text-yellow-400 fill-yellow-400" />
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
};

export default BillionaireAvatar;
