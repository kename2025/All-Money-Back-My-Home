// Web Audio API Synthesizer and Sound Effects Engine for the Billionaire H5 MV
class AudioEngineClass {
  private ctx: AudioContext | null = null;
  private isPlaying: boolean = false;
  private bpm: number = 120;
  private intervalId: any = null;
  private currentStep: number = 0;
  private onBeatCallback: ((step: number) => void) | null = null;

  // Sound Synth Settings
  private bassNotes = [55, 55, 65.41, 65.41, 73.42, 73.42, 82.41, 82.41]; // A1, C2, D2, E2 progression

  // Custom Background Song Support
  private customBuffer: AudioBuffer | null = null;
  private customSource: AudioBufferSourceNode | null = null;
  private customGainNode: GainNode | null = null;
  private analyserNode: AnalyserNode | null = null;
  private customStartTime: number = 0;
  private customOffset: number = 0;

  init() {
    if (this.ctx) return;
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (AudioContextClass) {
      this.ctx = new AudioContextClass();
    }
  }

  getAnalyser(): AnalyserNode | null {
    if (!this.ctx) return null;
    if (!this.analyserNode) {
      this.analyserNode = this.ctx.createAnalyser();
      this.analyserNode.fftSize = 64;
      this.analyserNode.connect(this.ctx.destination);
    }
    return this.analyserNode;
  }

  getAnalyserData(): Uint8Array | null {
    if (!this.analyserNode) return null;
    const array = new Uint8Array(this.analyserNode.frequencyBinCount);
    this.analyserNode.getByteFrequencyData(array);
    return array;
  }

  async loadCustomAudio(file: File): Promise<boolean> {
    this.init();
    if (!this.ctx) return false;
    try {
      const arrayBuffer = await file.arrayBuffer();
      const decodedBuffer = await this.ctx.decodeAudioData(arrayBuffer);
      this.customBuffer = decodedBuffer;
      this.customOffset = 0;
      return true;
    } catch (e) {
      console.error("Decoding audio failed:", e);
      return false;
    }
  }

  hasCustomAudio() {
    return this.customBuffer !== null;
  }

  clearCustomAudio() {
    this.stopCustom();
    this.customBuffer = null;
    this.customOffset = 0;
  }

  private startCustom() {
    if (!this.ctx || !this.customBuffer) return;
    this.stopCustom();

    const source = this.ctx.createBufferSource();
    source.buffer = this.customBuffer;
    source.loop = true;

    const analyser = this.getAnalyser();

    if (!this.customGainNode) {
      this.customGainNode = this.ctx.createGain();
      this.customGainNode.gain.setValueAtTime(0.7, this.ctx.currentTime);
    }

    source.connect(this.customGainNode);
    if (analyser) {
      this.customGainNode.connect(analyser);
    } else {
      this.customGainNode.connect(this.ctx.destination);
    }

    this.customStartTime = this.ctx.currentTime - this.customOffset;
    source.start(0, this.customOffset % this.customBuffer.duration);
    
    this.customSource = source;
  }

  private stopCustom() {
    if (this.customSource) {
      try {
        this.customSource.stop();
      } catch (e) {}
      this.customSource.disconnect();
      this.customSource = null;
    }
    if (this.ctx) {
      this.customOffset = this.ctx.currentTime - this.customStartTime;
    }
  }

  setBeatCallback(callback: (step: number) => void) {
    this.onBeatCallback = callback;
  }

  isEngineRunning() {
    return this.isPlaying;
  }

  toggle(forceState?: boolean) {
    this.init();
    if (!this.ctx) return false;

    const targetState = forceState !== undefined ? forceState : !this.isPlaying;

    if (targetState) {
      if (this.ctx.state === 'suspended') {
        this.ctx.resume();
      }
      if (this.customBuffer) {
        this.startCustom();
      }
      this.startLoop();
    } else {
      if (this.customBuffer) {
        this.stopCustom();
      }
      this.stopLoop();
    }
    return this.isPlaying;
  }

  private startLoop() {
    if (this.isPlaying) return;
    this.isPlaying = true;
    this.currentStep = 0;

    const stepDuration = 60 / this.bpm / 2; // Eighth notes
    let nextAudioTime = this.ctx!.currentTime;

    const schedule = () => {
      while (nextAudioTime < this.ctx!.currentTime + 0.1) {
        this.playBeatStep(this.currentStep, nextAudioTime);
        if (this.onBeatCallback) {
          // Trigger callbacks in sync
          const step = this.currentStep;
          setTimeout(() => this.onBeatCallback?.(step), (nextAudioTime - this.ctx!.currentTime) * 1000);
        }
        nextAudioTime += stepDuration;
        this.currentStep = (this.currentStep + 1) % 16;
      }
      if (this.isPlaying) {
        this.intervalId = setTimeout(schedule, 25);
      }
    };

    schedule();
  }

  private stopLoop() {
    this.isPlaying = false;
    if (this.intervalId) {
      clearTimeout(this.intervalId);
      this.intervalId = null;
    }
  }

  // Synthesize instruments in real-time
  private playBeatStep(step: number, time: number) {
    if (!this.ctx) return;

    // Skip synthesizing retro instruments if custom audio is playing!
    if (this.customBuffer) return;

    // 1. Synthesize Kick Drum on step 0, 4, 8, 12
    if (step % 4 === 0) {
      this.synthKick(time);
    }

    // 2. Synthesize Snare / Clap on step 4, 12 with some high pass noise
    if (step === 4 || step === 12) {
      this.synthSnare(time);
    }

    // 3. Synthesize Hi-Hat on offbeats
    if (step % 2 === 1) {
      this.synthHiHat(time);
    }

    // 4. Funky Bass Synths on select steps
    const activeBassSteps = [0, 2, 3, 5, 8, 10, 11, 14];
    if (activeBassSteps.includes(step)) {
      const noteIndex = Math.floor(step / 2) % this.bassNotes.length;
      const freq = this.bassNotes[noteIndex];
      this.synthBass(freq, time);
    }
  }

  private synthKick(time: number) {
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.connect(gain);
    
    const analyser = this.getAnalyser();
    if (analyser) {
      gain.connect(analyser);
    } else {
      gain.connect(this.ctx.destination);
    }

    osc.frequency.setValueAtTime(120, time);
    osc.frequency.exponentialRampToValueAtTime(0.01, time + 0.12);

    gain.gain.setValueAtTime(0.7, time);
    gain.gain.exponentialRampToValueAtTime(0.01, time + 0.12);

    osc.start(time);
    osc.stop(time + 0.15);
  }

  private synthSnare(time: number) {
    if (!this.ctx) return;
    // Simple noise-like snare snap
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    
    osc.type = 'triangle';
    osc.connect(gain);
    
    const analyser = this.getAnalyser();
    if (analyser) {
      gain.connect(analyser);
    } else {
      gain.connect(this.ctx.destination);
    }
    
    osc.frequency.setValueAtTime(220, time);
    osc.frequency.exponentialRampToValueAtTime(80, time + 0.1);
    
    gain.gain.setValueAtTime(0.4, time);
    gain.gain.exponentialRampToValueAtTime(0.01, time + 0.12);
    
    osc.start(time);
    osc.stop(time + 0.15);
  }

  private synthHiHat(time: number) {
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.connect(gain);
    
    const analyser = this.getAnalyser();
    if (analyser) {
      gain.connect(analyser);
    } else {
      gain.connect(this.ctx.destination);
    }

    osc.frequency.setValueAtTime(8000, time);
    gain.gain.setValueAtTime(0.12, time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + 0.05);

    osc.start(time);
    osc.stop(time + 0.06);
  }

  private synthBass(freq: number, time: number) {
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.connect(gain);
    
    const analyser = this.getAnalyser();
    if (analyser) {
      gain.connect(analyser);
    } else {
      gain.connect(this.ctx.destination);
    }

    osc.frequency.setValueAtTime(freq, time);
    gain.gain.setValueAtTime(0.2, time);
    gain.gain.linearRampToValueAtTime(0.12, time + 0.1);
    gain.gain.exponentialRampToValueAtTime(0.001, time + 0.22);

    osc.start(time);
    osc.stop(time + 0.25);
  }

  // --- PLAY INTEGRATED SFX ON-DEMAND ---

  playCoinSFX() {
    this.init();
    if (!this.ctx) return;
    const time = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.connect(gain);
    gain.connect(this.ctx.destination);

    // Iconic retro high-pitched coin dual chime (e.g. 987Hz -> 1318Hz)
    osc.frequency.setValueAtTime(987.77, time); // B5
    osc.frequency.setValueAtTime(1318.51, time + 0.08); // E6

    gain.gain.setValueAtTime(0.15, time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + 0.25);

    osc.start(time);
    osc.stop(time + 0.28);
  }

  playGlassBreakSFX() {
    this.init();
    if (!this.ctx) return;
    const time = this.ctx.currentTime;

    // Synthesize several high frequency noise spikes to mimic glass shatter
    for (let i = 0; i < 5; i++) {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sawtooth';
      osc.connect(gain);
      gain.connect(this.ctx.destination);

      const freq = 3000 + Math.random() * 4000;
      osc.frequency.setValueAtTime(freq, time + i * 0.02);
      gain.gain.setValueAtTime(0.1, time + i * 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, time + 0.1 + Math.random() * 0.15);

      osc.start(time + i * 0.02);
      osc.stop(time + 0.35);
    }
  }

  playChimeSFX() {
    this.init();
    if (!this.ctx) return;
    const time = this.ctx.currentTime;
    
    // Smooth rising harp/bell chime
    const notes = [261.63, 329.63, 392.00, 523.25, 659.25]; // C4, E4, G4, C5, E5
    notes.forEach((freq, idx) => {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.frequency.setValueAtTime(freq, time + idx * 0.05);
      gain.gain.setValueAtTime(0.15, time + idx * 0.05);
      gain.gain.exponentialRampToValueAtTime(0.001, time + 0.3 + idx * 0.05);

      osc.start(time + idx * 0.05);
      osc.stop(time + 0.45 + idx * 0.05);
    });
  }

  playRocketSFX() {
    this.init();
    if (!this.ctx) return;
    const time = this.ctx.currentTime;
    
    // Low rumble sweep upwards
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    
    osc.type = 'sawtooth';
    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.frequency.setValueAtTime(30, time);
    osc.frequency.exponentialRampToValueAtTime(600, time + 1.2);

    gain.gain.setValueAtTime(0.4, time);
    gain.gain.linearRampToValueAtTime(0.6, time + 0.3);
    gain.gain.exponentialRampToValueAtTime(0.001, time + 1.3);

    osc.start(time);
    osc.stop(time + 1.5);
  }

  playCyberLaserSFX() {
    this.init();
    if (!this.ctx) return;
    const time = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'triangle';
    osc.connect(gain);
    gain.connect(this.ctx.destination);

    // Laser sweep down
    osc.frequency.setValueAtTime(2000, time);
    osc.frequency.exponentialRampToValueAtTime(100, time + 0.25);

    gain.gain.setValueAtTime(0.15, time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + 0.28);

    osc.start(time);
    osc.stop(time + 0.3);
  }

  playChampagneSFX() {
    this.init();
    if (!this.ctx) return;
    const time = this.ctx.currentTime;
    
    // Quick pop and sparkle
    const popOsc = this.ctx.createOscillator();
    const popGain = this.ctx.createGain();
    popOsc.type = 'sine';
    popOsc.connect(popGain);
    popGain.connect(this.ctx.destination);

    popOsc.frequency.setValueAtTime(150, time);
    popOsc.frequency.exponentialRampToValueAtTime(450, time + 0.05);
    popGain.gain.setValueAtTime(0.3, time);
    popGain.gain.exponentialRampToValueAtTime(0.001, time + 0.08);

    popOsc.start(time);
    popOsc.stop(time + 0.1);

    // High speed sparkle tics
    for (let i = 0; i < 8; i++) {
      const ticOsc = this.ctx.createOscillator();
      const ticGain = this.ctx.createGain();
      ticOsc.type = 'sine';
      ticOsc.connect(ticGain);
      ticGain.connect(this.ctx.destination);

      ticOsc.frequency.setValueAtTime(4000 + Math.random() * 2000, time + 0.05 + i * 0.03);
      ticGain.gain.setValueAtTime(0.08, time + 0.05 + i * 0.03);
      ticGain.gain.exponentialRampToValueAtTime(0.001, time + 0.08 + i * 0.03);

      ticOsc.start(time + 0.05 + i * 0.03);
      ticOsc.stop(time + 0.15 + i * 0.03);
    }
  }

  // Speak voice synthesizer (Singing)
  speakLyric(text: string) {
    if (!('speechSynthesis' in window)) return;
    
    // Cancel prior speech first to stay responsive
    window.speechSynthesis.cancel();
    
    const utterance = new SpeechSynthesisUtterance(text);
    // Find a fun English or robotic voice
    const voices = window.speechSynthesis.getVoices();
    const targetVoice = voices.find(v => v.lang.includes('en') || v.name.toLowerCase().includes('robot') || v.name.toLowerCase().includes('google'));
    if (targetVoice) {
      utterance.voice = targetVoice;
    }
    
    utterance.pitch = 1.3; // Higher energy
    utterance.rate = 1.15; // Punchy
    utterance.volume = 0.85;

    window.speechSynthesis.speak(utterance);
  }
}

export const AudioEngine = new AudioEngineClass();
export default AudioEngine;
