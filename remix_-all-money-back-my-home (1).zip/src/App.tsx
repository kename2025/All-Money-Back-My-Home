import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Coins,
  Play,
  Pause,
  Volume2,
  VolumeX,
  ChevronLeft,
  ChevronRight,
  Sparkles,
  Zap,
  RotateCcw,
  Music,
  Tv,
  Users,
  Terminal,
  Compass,
  ArrowDown
} from 'lucide-react';
import CoinCanvas, { CoinCanvasRef } from './components/CoinCanvas';
import InteractiveSlide from './components/InteractiveSlide';
import AudioEngine from './components/AudioEngine';
import { BILLIONAIRE_DATA, SONG_LYRICS } from './data';

export default function App() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentSlideIndex, setCurrentSlideIndex] = useState(-1); // -1 is the Cover Page
  const [currentLyricIndex, setCurrentLyricIndex] = useState(0);
  const [isSpeakEnabled, setIsSpeakEnabled] = useState(true);
  const [isAutoMvMode, setIsAutoMvMode] = useState(false);
  const [beatPulse, setBeatPulse] = useState(false);
  const [visualizerBars, setVisualizerBars] = useState<number[]>(Array(10).fill(15));
  const canvasRef = useRef<CoinCanvasRef | null>(null);

  const [isCustomLoaded, setIsCustomLoaded] = useState(false);
  const [customBgmName, setCustomBgmName] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleAudioUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const success = await AudioEngine.loadCustomAudio(file);
      if (success) {
        setIsCustomLoaded(true);
        setCustomBgmName(file.name);
        // Automatically trigger play state for direct playback
        handleToggleMusic(true);
        canvasRef.current?.spawnParticles('diamond', 30);
      }
    }
  };

  const handleClearCustomAudio = () => {
    AudioEngine.clearCustomAudio();
    setIsCustomLoaded(false);
    setCustomBgmName('');
    handleToggleMusic(false);
  };

  // Auto progression timer
  const mvTimerRef = useRef<any>(null);
  const [currentTimeSec, setCurrentTimeSec] = useState(0);

  // Initialize Audio Beats Callback to sync visuals
  useEffect(() => {
    AudioEngine.setBeatCallback((step) => {
      // Flashes background grids on beats
      setBeatPulse((prev) => !prev);
    });
  }, []);

  // Real Frequency Visualizer FFT sampling
  useEffect(() => {
    let animId: number;
    const sampleFrequency = () => {
      if (isPlaying) {
        const fftData = AudioEngine.getAnalyserData();
        if (fftData && fftData.length > 0) {
          // Normalize and scale fft results mapping to 10 visualizer bars
          const normalized = Array.from({ length: 10 }).map((_, idx) => {
            const startBin = idx * 2;
            const avgVal = (fftData[startBin] + (fftData[startBin + 1] || fftData[startBin])) / 2;
            return Math.min(Math.max((avgVal / 255) * 85 + 15, 15), 100);
          });
          setVisualizerBars(normalized);
        } else {
          // Keep slightly bouncing if analyzer has no feedback
          setVisualizerBars((prev) =>
            prev.map(() => Math.floor(Math.random() * 40) + 15)
          );
        }
      } else {
        // Flatline slightly when stopped
        setVisualizerBars((prev) => prev.map((h) => Math.max(h - 4, 15)));
      }
      animId = requestAnimationFrame(sampleFrequency);
    };
    animId = requestAnimationFrame(sampleFrequency);
    return () => cancelAnimationFrame(animId);
  }, [isPlaying]);

  // Sync Karaoke Lyrics & Auto Slide Progression based on time
  useEffect(() => {
    if (isAutoMvMode && isPlaying) {
      mvTimerRef.current = setInterval(() => {
        setCurrentTimeSec((prev) => {
          const nextTime = prev + 1;
          
          // Match karaoke lyrics index
          const matchingLyricIdx = SONG_LYRICS.findIndex(
            (l, idx) => nextTime >= l.timeSec && (idx === SONG_LYRICS.length - 1 || nextTime < SONG_LYRICS[idx + 1].timeSec)
          );
          if (matchingLyricIdx !== -1) {
            setCurrentLyricIndex(matchingLyricIdx);
            
            // Speaks lyrics organically
            if (isSpeakEnabled && currentTimeSec % 4 === 0) {
              const speakText = SONG_LYRICS[matchingLyricIdx].text;
              AudioEngine.speakLyric(speakText);
            }
          }

          // Force transition slide based on lyric mappings
          // Mappings roughly: every 8 seconds we move to a new billionaire
          // Since we have cover (-1) and 9 billionaire slides:
          if (nextTime === 1) {
            setCurrentSlideIndex(0); // Slide 10: Google
          } else if (nextTime === 16) {
            setCurrentSlideIndex(1); // Slide 9: Ballmer
          } else if (nextTime === 24) {
            setCurrentSlideIndex(2); // Slide 8: Gates
          } else if (nextTime === 32) {
            setCurrentSlideIndex(3); // Slide 7: Buffett
          } else if (nextTime === 40) {
            setCurrentSlideIndex(4); // Slide 6: Ellison
          } else if (nextTime === 48) {
            setCurrentSlideIndex(5); // Slide 5: Zuck
          } else if (nextTime === 56) {
            setCurrentSlideIndex(6); // Slide 4: Bezos
          } else if (nextTime === 64) {
            setCurrentSlideIndex(7); // Slide 3: Arnault
          } else if (nextTime === 72) {
            setCurrentSlideIndex(8); // Slide 1/2: Musk
          } else if (nextTime >= 95) {
            // Loop back or stay on epic Musk SpaceX Mars rain
            canvasRef.current?.spawnParticles('gold_bar', 10);
          }

          return nextTime;
        });
      }, 1000);
    } else {
      if (mvTimerRef.current) {
        clearInterval(mvTimerRef.current);
      }
    }

    return () => {
      if (mvTimerRef.current) {
        clearInterval(mvTimerRef.current);
      }
    };
  }, [isAutoMvMode, isPlaying, isSpeakEnabled, currentTimeSec]);

  // Audio start toggle from user interactions
  const handleToggleMusic = (forceState?: boolean) => {
    const nextState = AudioEngine.toggle(forceState);
    setIsPlaying(nextState);
    if (nextState) {
      canvasRef.current?.spawnParticles('coin', 40);
    }
  };

  // Launch H5 Click handler
  const handleStartH5 = () => {
    handleToggleMusic(true);
    setCurrentSlideIndex(0); // Jump to Rank 10 Larry/Sergey
    canvasRef.current?.spawnParticles('coin', 60);
    AudioEngine.playChimeSFX();
    
    // Automatically flag Auto MV Mode for full cinematic storytelling experience!
    setIsAutoMvMode(true);
  };

  // Skip slides manual override
  const handleNavigateSlide = (dir: 'next' | 'prev') => {
    // Disable automatic MV mode to let user click manual slides securely
    setIsAutoMvMode(false);
    
    if (dir === 'next') {
      if (currentSlideIndex < BILLIONAIRE_DATA.length - 1) {
        const nextIdx = currentSlideIndex + 1;
        setCurrentSlideIndex(nextIdx);
        // Sync static lyrics
        setCurrentLyricIndex(Math.min(nextIdx * 2 + 1, SONG_LYRICS.length - 1));
        AudioEngine.playCoinSFX();
      }
    } else {
      if (currentSlideIndex > -1) {
        const prevIdx = currentSlideIndex - 1;
        setCurrentSlideIndex(prevIdx);
        if (prevIdx === -1) {
          setCurrentLyricIndex(0);
        } else {
          setCurrentLyricIndex(Math.max(prevIdx * 2, 0));
        }
        AudioEngine.playCoinSFX();
      }
    }
  };

  const currentBillionaire = currentSlideIndex >= 0 ? BILLIONAIRE_DATA[currentSlideIndex] : null;

  return (
    <div className="relative min-h-screen bg-[#0a0a0a] text-slate-100 flex flex-col justify-between overflow-x-hidden select-none crt-overlay font-sans">
      
      {/* Scattered ambient coins backdrop */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-0 opacity-20">
        <div className="absolute top-[12%] left-[15%] w-10 h-10 rounded-full gold-gradient border-2 border-[#8B4513] shadow-lg flex items-center justify-center font-black text-black text-lg rotate-12 animate-pulse">$</div>
        <div className="absolute top-[25%] right-[10%] w-10 h-10 rounded-full gold-gradient border-2 border-[#8B4513] shadow-lg flex items-center justify-center font-black text-black text-lg -rotate-6 animate-pulse">$</div>
        <div className="absolute bottom-[20%] left-[38%] w-10 h-10 rounded-full gold-gradient border-2 border-[#8B4513] shadow-lg flex items-center justify-center font-black text-black text-lg rotate-[25deg]">$</div>
        <div className="absolute top-[48%] left-[8%] w-10 h-10 rounded-full gold-gradient border-2 border-[#8B4513] shadow-lg flex items-center justify-center font-black text-black text-lg -rotate-12">$</div>
        <div className="absolute bottom-[32%] right-[18%] w-10 h-10 rounded-full gold-gradient border-2 border-[#8B4513] shadow-lg flex items-center justify-center font-black text-black text-lg rotate-3">$</div>
      </div>

      {/* High-Performance Canvas Particles background */}
      <CoinCanvas
        ref={canvasRef}
        activeRank={currentBillionaire ? currentBillionaire.rank : undefined}
        intensity={isPlaying ? (currentSlideIndex === 8 ? 70 : 25) : 8}
      />

      {/* Grid Pattern Beats Indicator Overlay */}
      <div
        className={`fixed inset-0 pointer-events-none z-0 opacity-[0.02] transition-all duration-150 bg-[linear-gradient(to_right,#808080_1px,transparent_1px),linear-gradient(to_bottom,#808080_1px,transparent_1px)] bg-[size:24px_24px] ${
          beatPulse && isPlaying ? 'scale-[1.01] opacity-[0.05] border-4 border-yellow-500/10' : ''
        }`}
      />

      {/* HEADER: Dynamic Controllers & Soundboard */}
      <header className="w-full z-40 bg-[#0a0a0a]/90 backdrop-blur-md border-b border-white/10 py-5 px-8 flex flex-col md:flex-row gap-4 justify-between items-center relative">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 gold-gradient rounded-full flex items-center justify-center font-black text-black text-2xl shadow-[0_0_15px_rgba(255,215,0,0.5)]">
            $
          </div>
          <div>
            <h1 className="font-display font-black text-xl lg:text-2xl tracking-widest uppercase leading-none gold-text">
              ALL MONEY BACK MY HOME
            </h1>
            <span className="text-[10px] font-mono tracking-widest text-slate-400 uppercase block mt-1">
              Billionaire MV Portfolio • Suno AI x Frontend Interaction
            </span>
          </div>
        </div>

        {/* Audio Live Synth Synthesizer Controls */}
        <div className="flex flex-wrap items-center gap-3 bg-slate-900/40 p-1.5 rounded-xl border border-white/5">
          {/* Beat Visualizer Bar graphs */}
          <div className="flex items-end gap-0.5 h-6 px-3">
            {visualizerBars.map((h, i) => (
              <motion.div
                key={i}
                animate={{ height: isPlaying ? `${h}%` : '20%' }}
                transition={{ type: 'spring', damping: 6 }}
                className={`w-1 rounded-t ${isPlaying ? 'bg-amber-400' : 'bg-slate-700'}`}
              />
            ))}
          </div>

          {/* Sound Pad Synth Triggers (Jam soundboard) */}
          <div className="hidden lg:flex items-center gap-1 border-r border-white/10 pr-3 mr-1 text-[10px] font-mono">
            <span className="text-slate-500 mr-1 uppercase">SOUNDBOARD:</span>
            <button
              onClick={() => { AudioEngine.playCoinSFX(); canvasRef.current?.spawnParticles('coin', 12); }}
              className="bg-slate-800 hover:bg-slate-700 text-yellow-400 px-2 py-1 rounded cursor-pointer border border-yellow-500/10 active:scale-95 transition-all text-[9.5px]"
            >
              🔔 COIN
            </button>
            <button
              onClick={() => { AudioEngine.playGlassBreakSFX(); canvasRef.current?.spawnParticles('gold_bar', 5); }}
              className="bg-slate-800 hover:bg-slate-700 text-sky-400 px-2 py-1 rounded cursor-pointer border border-sky-500/10 active:scale-95 transition-all text-[9.5px]"
            >
              💥 SPLIT
            </button>
            <button
              onClick={() => { AudioEngine.playChimeSFX(); canvasRef.current?.spawnParticles('dollar', 8); }}
              className="bg-slate-800 hover:bg-slate-700 text-green-400 px-2 py-1 rounded cursor-pointer border border-green-500/10 active:scale-95 transition-all text-[9.5px]"
            >
              📈Compound
            </button>
            <button
              onClick={() => { AudioEngine.playRocketSFX(); canvasRef.current?.spawnParticles('gold_bar', 15); }}
              className="bg-slate-800 hover:bg-slate-700 text-fuchsia-400 px-2 py-1 rounded cursor-pointer border border-fuchsia-500/10 active:scale-95 transition-all text-[9.5px]"
            >
              🚀 BLASTER
            </button>
          </div>

          <button
            onClick={() => handleToggleMusic()}
            className={`cursor-pointer px-4 py-1.5 rounded-lg font-display text-xs font-bold transition-all duration-300 flex items-center gap-1.5 ${
              isPlaying
                ? 'bg-red-500 hover:bg-red-600 text-white'
                : 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-900 glow-btn font-black'
            }`}
          >
            {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            {isPlaying ? 'PAUSE BGM' : isCustomLoaded ? 'PLAY MUSIC' : 'START SYNTH'}
          </button>

          {/* Custom BGM Upload */}
          <div className="flex items-center gap-2">
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleAudioUpload}
              accept="audio/*"
              className="hidden"
            />
            {isCustomLoaded ? (
              <div className="flex items-center gap-1.5 bg-green-950/45 border border-green-500/30 px-3 py-1.5 rounded-lg text-xs">
                <Music className="w-3.5 h-3.5 text-green-400 animate-pulse" />
                <span className="text-green-300 max-w-[120px] truncate font-mono uppercase text-[10px]" title={customBgmName}>
                  {customBgmName}
                </span>
                <button
                  onClick={handleClearCustomAudio}
                  className="hover:text-red-400 text-slate-400 p-0.5 ml-1 transition cursor-pointer"
                  title="Remove custom background music"
                >
                  <RotateCcw className="w-3 h-3" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => fileInputRef.current?.click()}
                className="cursor-pointer bg-slate-800 hover:bg-slate-700 text-slate-200 border border-white/10 px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5"
                title="Upload MP3/WAV to replace the background synthesizer beats"
              >
                <Music className="w-3.5 h-3.5 text-amber-400 hover:animate-bounce" />
                <span>REPLACE BGM</span>
              </button>
            )}
          </div>

          {/* TTS Robot vocal control */}
          <button
            onClick={() => setIsSpeakEnabled(!isSpeakEnabled)}
            className={`cursor-pointer p-1.5 rounded-lg border text-xs transition-all ${
              isSpeakEnabled
                ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                : 'bg-slate-800 border-slate-700 text-slate-500'
            }`}
            title="Toggle Robotic Lyric vocals"
          >
            {isSpeakEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>

          {/* AUTO PLAY MV SYSTEM */}
          <button
            onClick={() => {
              setIsAutoMvMode(!isAutoMvMode);
              if (!isAutoMvMode) {
                // Initialize timestamp tracker
                setCurrentTimeSec(0);
                handleToggleMusic(true);
              }
            }}
            className={`cursor-pointer px-3 py-1.5 rounded-lg border text-xs font-mono font-bold transition-all uppercase ${
              isAutoMvMode
                ? 'bg-fuchsia-950/60 text-fuchsia-300 border-fuchsia-500 animate-pulse'
                : 'bg-slate-800 text-slate-400 border-slate-700'
            }`}
          >
            📺 Auto MV: {isAutoMvMode ? 'ON' : 'OFF'}
          </button>
        </div>
      </header>

      {/* MAIN CAROUSEL / SLIDES AREA */}
      <main className="flex-1 w-full max-w-7xl mx-auto flex items-center justify-center py-6 px-4 relative min-h-[500px]">
        <AnimatePresence mode="wait">
          {currentSlideIndex === -1 ? (
            /* COVER PLAY PAGE (第0屏) */
            <motion.div
              key="cover"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.05 }}
              transition={{ duration: 0.5 }}
              className="text-center w-full max-w-3xl glass p-8 lg:p-12 rounded-3xl border-white/10 shadow-2xl relative overflow-hidden flex flex-col items-center justify-center bg-[#0a0a0a]/90"
            >
              {/* Backsplash gold shine */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-yellow-500/5 blur-3xl rounded-full" />

              <div className="absolute right-4 top-4 bg-white/5 text-amber-400 text-[10px] font-mono px-3 py-1 rounded border border-white/10 animate-pulse">
                ⏰ SYSTEM_CLK: 2026_ACTIVE
              </div>

              {/* Retro Glowing Neon frame */}
              <div className="inline-block relative p-6 border-2 border-dashed border-yellow-500/30 rounded-2xl bg-black/80 shadow-[0_0_40px_rgba(255,215,0,0.1)] mb-8">
                {/* Neon lights bulbs styled dynamically */}
                <div className="absolute -top-1.5 -left-1.5 w-3 h-3 bg-yellow-400 rounded-full animate-ping" />
                <div className="absolute -bottom-1.5 -right-1.5 w-3 h-3 bg-amber-500 rounded-full animate-ping delay-500" />

                <h2 className="font-display font-black text-4xl lg:text-7xl text-center leading-none tracking-widest uppercase select-none drop-shadow-[0_4px_10px_rgba(0,0,0,0.8)]">
                  <span className="text-white block">富豪排行榜</span>
                  <span className="gold-text block mt-2 font-black animate-neon-pulse">
                    ALL MONEY BACK MY HOME
                  </span>
                </h2>
              </div>

              <p className="font-serif italic text-lg text-slate-300 font-medium mb-12 max-w-xl mx-auto leading-relaxed">
                “一页一富豪，滚动吐千金！”<br />
                <span className="font-sans text-xs not-italic text-slate-400 block mt-2 tracking-[0.1em] leading-relaxed">
                  随着这首劲爆的 Suno《发财歌》MV背景，向下滚动页面或开启 Auto播放，看 10 位科技与实体商业巨鳄们如何奉陪到底，为您倾泻大财！
                </span>
              </p>

              {/* Enter Button */}
              <button
                onClick={handleStartH5}
                className="cursor-pointer bg-gradient-to-br from-[#FFD700] to-[#B8860B] text-black font-display font-black tracking-widest text-[#0a0a0a] text-sm lg:text-base px-12 py-5 rounded-full transition-all duration-300 shadow-[0_10px_35px_rgba(255,215,0,0.3)] border border-white/20 hover:scale-105 active:scale-95 glow-btn mt-2 flex items-center gap-3 uppercase"
              >
                <Play className="w-5 h-5 fill-slate-950" />
                点击启程 / PLAY MV
              </button>

              <div className="flex items-center gap-1.5 text-[11px] font-mono text-slate-500 mt-12 animate-bounce">
                <ArrowDown className="w-3.5 h-3.5 gold-text" />
                <span>Scroll down or click the play button to initiate H5 beats!</span>
              </div>
            </motion.div>
          ) : (
            /* ACTIVE BILLIONAIRE INTERACTIONS SLIDE */
            <motion.div
              key={currentSlideIndex}
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              transition={{ duration: 0.4 }}
              className="w-full flex justify-center items-center"
            >
              {currentBillionaire && (
                <InteractiveSlide
                  slide={currentBillionaire}
                  onSpawnParticles={(type, count, sx, sy) => canvasRef.current?.spawnParticles(type, count, sx, sy)}
                />
              )}
            </motion.div>
          )}
        </AnimatePresence>

        {/* SIDEBAR DIAL CHANNELS FOR RAPID NAVIGATION */}
        <div className="absolute right-2 md:right-8 top-1/2 -translate-y-1/2 flex flex-col gap-2.5 z-30 bg-black/40 p-2.5 rounded-2xl border border-white/5 backdrop-blur-sm">
          <button
            onClick={() => {
              setCurrentSlideIndex(-1);
              setIsAutoMvMode(false);
            }}
            className={`cursor-pointer px-2.5 py-1.5 rounded-lg border text-[10px] font-mono font-black transition-all tracking-wider ${
              currentSlideIndex === -1
                ? 'gold-gradient text-black border-[#FFD700] shadow-[0_0_15px_rgba(255,215,0,0.4)] scale-110'
                : 'bg-black/60 text-slate-400 border-white/10 hover:bg-white/5'
            }`}
          >
            COVER
          </button>
          {BILLIONAIRE_DATA.map((item, idx) => (
            <button
              key={item.rank}
              onClick={() => {
                setCurrentSlideIndex(idx);
                setIsAutoMvMode(false);
                // Highlight lyrics appropriately
                setCurrentLyricIndex(Math.min(idx * 2 + 1, SONG_LYRICS.length - 1));
                AudioEngine.playCoinSFX();
              }}
              style={{ contentVisibility: 'auto' }}
              className={`cursor-pointer w-9 h-9 flex items-center justify-center rounded-full border text-xs font-mono font-bold transition-all ${
                currentSlideIndex === idx
                  ? 'gold-gradient text-black border-[#FFD700] shadow-[0_0_15px_rgba(255,215,0,0.5)] scale-120'
                  : 'bg-black/60 text-slate-400 border-white/10 hover:bg-white/5'
              }`}
            >
              #{item.rank === 12 ? '2/1' : item.rank}
            </button>
          ))}
        </div>
      </main>

      {/* FOOTER: Bilingual Karaoke Tracker & Music Controls */}
      <footer className="w-full z-40 bg-slate-950/80 backdrop-blur-md border-t border-white/5 p-4 flex flex-col md:flex-row gap-4 items-center justify-between">
        
        {/* MANUAL PROGRESS ARROWS (Left & Right) */}
        <div className="flex gap-2">
          <button
            onClick={() => handleNavigateSlide('prev')}
            disabled={currentSlideIndex === -1}
            className={`p-2.5 rounded-lg border transition-all ${
              currentSlideIndex === -1
                ? 'bg-slate-950 text-slate-700 border-transparent cursor-not-allowed'
                : 'bg-slate-900 hover:bg-slate-800 border-white/5 cursor-pointer text-white'
            }`}
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <div className="flex flex-col items-center justify-center px-4 font-mono text-xs text-slate-400 border-x border-white/5">
            <span className="font-extrabold text-white text-[13px]">
              {currentSlideIndex === -1 ? '00' : currentSlideIndex + 1} / {BILLIONAIRE_DATA.length}
            </span>
            <span className="text-[9px] uppercase tracking-widest text-[#94A3B8]">PAGE_INDEX</span>
          </div>
          <button
            onClick={() => handleNavigateSlide('next')}
            disabled={currentSlideIndex === BILLIONAIRE_DATA.length - 1}
            className={`p-2.5 rounded-lg border transition-all ${
              currentSlideIndex === BILLIONAIRE_DATA.length - 1
                ? 'bg-slate-950 text-slate-700 border-transparent cursor-not-allowed'
                : 'bg-slate-900 hover:bg-slate-800 border-white/5 cursor-pointer text-white'
            }`}
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>

        {/* HIGH CONTRAST BILINGUAL KARAOKE SUBTITLE BOX */}
        <div className="flex-1 max-w-xl mx-4 text-center bg-black/90 border border-white/10 p-4 rounded-xl shadow-inner relative overflow-hidden flex flex-col justify-center min-h-[72px] glass">
          {isAutoMvMode && isPlaying && (
            <div className="absolute top-1 left-3 text-[9px] font-mono text-[#FFD700] tracking-wider font-extrabold animate-pulse">
              SYNCING MV TIMER: {Math.floor(currentTimeSec / 60)}:{(currentTimeSec % 60).toString().padStart(2, '0')}
            </div>
          )}
          <div className="absolute top-1 right-3 text-[9px] font-mono text-slate-500 uppercase font-bold">
            {isAutoMvMode ? 'AUTOPLAY SYNCHRONIZED' : 'MANUAL SCROLL MODE'}
          </div>
          <p className="font-display font-black text-base lg:text-lg tracking-wide gold-text truncate mt-1">
            {SONG_LYRICS[currentLyricIndex]?.text || 'Choose a slide or click PLAY MV to start lyrics tracker!'}
          </p>
          <p className="font-sans font-semibold text-xs text-slate-400 truncate mt-1">
            {SONG_LYRICS[currentLyricIndex]?.translation || '选择频道或点击开启发财歌，即刻卡拉OK唱词！'}
          </p>
        </div>

        {/* SUB FOOTER RIGHTS & STATS */}
        <div className="flex items-center gap-4 text-[10px] font-mono text-slate-500">
          <div className="flex items-center gap-1 bg-[#FFD700]/10 border border-[#FFD700]/30 text-[#FFD700] px-3 py-1 rounded animate-pulse">
            <Sparkles className="w-3.5 h-3.5 fill-[#FFD700]/25 text-[#FFD700]" />
            <span className="font-bold">FORTUNE_ACTIVE: 99.9%</span>
          </div>
          <span className="font-bold">v1.2.5</span>
        </div>
      </footer>
    </div>
  );
}
