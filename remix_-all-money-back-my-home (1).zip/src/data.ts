import { BillionaireSlide, LyricLine } from './types';

export const BILLIONAIRE_DATA: BillionaireSlide[] = [
  {
    rank: 10,
    name: "Larry Page & Sergey Brin",
    cnName: "拉里·佩奇 & 谢尔盖·布林",
    title: "Google Founders / 联手创始人",
    company: "Google / Alphabet",
    netWorth: "$145.2 Billion",
    avatarUrl: "google",
    description: "They created the entry point of the web. Type inside the search box below to trigger a massive explosion of 'G' fortune particles!",
    lyrics: "搜索框里藏着真金，Google PageRank算得清！\n(Gold is hidden in the search box, PageRank calculates the treasure!)",
    colorTheme: "from-blue-600/90 to-red-600/90",
    bgAccent: "bg-blue-950/40"
  },
  {
    rank: 9,
    name: "Steve Ballmer",
    cnName: "史蒂夫·鲍尔默",
    title: "The Hype Master / 激情狂人",
    company: "Microsoft Former CEO",
    netWorth: "$140.5 Billion",
    avatarUrl: "ballmer",
    description: "Developers, developers, developers! He sweats money and bleeds enthusiasm. Click the dance button to sync his feverish rhythm!",
    lyrics: "激情狂人鲍尔默，双手一挥黄金多！\n(Steve Ballmer yells and claps, making gold fall into our laps!)",
    colorTheme: "from-amber-500/90 to-orange-600/90",
    bgAccent: "bg-orange-950/40"
  },
  {
    rank: 8,
    name: "Bill Gates",
    cnName: "比尔·盖茨",
    title: "Tech Godfather / 科技教父",
    company: "Microsoft Founder",
    netWorth: "$130.4 Billion",
    avatarUrl: "gates",
    description: "The father of personal computing. Watch out for the Blue Screen of Death, which unlocks a hidden fortune!",
    lyrics: "微机教父盖茨君，蓝屏一碎尽是金！\n(Tech Godfather Bill Gates, crashes windows to open gates of gold!)",
    colorTheme: "from-cyan-600/90 to-blue-700/90",
    bgAccent: "bg-cyan-950/40"
  },
  {
    rank: 7,
    name: "Warren Buffett",
    cnName: "沃伦·巴菲特",
    title: "Omaha Oracle / 股神巴太师",
    company: "Berkshire Hathaway",
    netWorth: "$135.8 Billion",
    avatarUrl: "buffett",
    description: "Compound interest is his superpower, Cherry Coke is his fuel. Click his Coke to witness cash flow upward and green candlesticks rally!",
    lyrics: "可乐配上汉堡包，股神带你上九霄！\n(Sip some Coke and eat a burger, the Oracle of Omaha sends stocks to the sky!)",
    colorTheme: "from-emerald-600/90 to-teal-700/90",
    bgAccent: "bg-emerald-950/40"
  },
  {
    rank: 6,
    name: "Larry Ellison",
    cnName: "拉里·埃里森",
    title: "Database Giant / 数据库霸主",
    company: "Oracle Corporation",
    netWorth: "$172.1 Billion",
    avatarUrl: "ellison",
    description: "Lord of the digital cloud. He owns whole islands and mega-yachts. Open his database vault to dump literal gold bars on your layout!",
    lyrics: "数据巨头埃里森，云端数据库聚宝盆！\n(Database master Larry, his central cloud is a literal treasure chest!)",
    colorTheme: "from-rose-600/90 to-red-800/90",
    bgAccent: "bg-red-950/40"
  },
  {
    rank: 5,
    name: "Mark Zuckerberg",
    cnName: "马克·扎克伯格",
    title: "Metaverse Pioneer / 元宇宙行者",
    company: "Meta (Facebook)",
    netWorth: "$178.6 Billion",
    avatarUrl: "zuckerberg",
    description: "Step into the cyberpunk headset. Hover or tap his VR glasses to enter a neo-cyber dimension loaded with floating Dogecoins!",
    lyrics: "元宇宙里虚幻梦，扎导带你抢先冲！\n(Metaverse dreams are bold, Zuck shows us virtual gold!)",
    colorTheme: "from-purple-600/90 to-indigo-800/90",
    bgAccent: "bg-purple-950/40"
  },
  {
    rank: 4,
    name: "Jeff Bezos",
    cnName: "杰夫·贝佐斯",
    title: "eCommerce Emperor / 电商之王",
    company: "Amazon Founder",
    netWorth: "$195.4 Billion",
    avatarUrl: "bezos",
    description: "The master of fast delivery and outer space spaceflight. Open his giant Amazon cardboard box to dispatch a drone fleet hauling heavy coin bags!",
    lyrics: "纸箱打开飞无人，送货送钱到你门！\n(Open the Amazon parcel, and drones deliver bags of coins directly to your castle!)",
    colorTheme: "from-amber-600/90 to-yellow-500/90",
    bgAccent: "bg-yellow-950/40"
  },
  {
    rank: 3,
    name: "Bernard Arnault",
    cnName: "伯纳德·阿尔诺",
    title: "Luxury Sovereign / 奢侈品帝王",
    company: "LVMH Group",
    netWorth: "$210.3 Billion",
    avatarUrl: "arnault",
    description: "He wrapped the world in champagne and haute couture. Tap his designer bags to unzip infinite golden beams and luxurious effervescent bubbles!",
    lyrics: "名牌包包真高贵，阿王一叹满堂醉！\n(Luxury handbags sparkle high, Arnault makes champagne bubbles fly!)",
    colorTheme: "from-stone-700/90 to-zinc-900/90",
    bgAccent: "bg-zinc-950/40"
  },
  {
    rank: 12, // Custom combined Rank representing the ultimate climax
    name: "Elon Musk",
    cnName: "埃隆·马斯克",
    title: "The Rocket Technoking / 科技狂人",
    company: "Tesla & SpaceX",
    netWorth: "$230.1 Billion",
    avatarUrl: "musk",
    description: "Mars colonization, electric speed, and meme engineering. The ultimate climax of our song! Tap to launch SpaceX payloads and crash the sky into golden firework rain!",
    lyrics: "特斯拉配大火箭，马哥狂飙冲云间！\n(Meme maestro of outer space, Musk wins the Martian race!)",
    colorTheme: "from-violet-600/90 to-fuchsia-700/90",
    bgAccent: "bg-fuchsia-950/40"
  }
];

export const SONG_LYRICS: LyricLine[] = [
  { text: "🎵 Welcome to the Rich List MV 🎵", translation: "🎵 欢迎来到富豪榜发财歌 🎵", timeSec: 0 },
  { text: "All money back my home! Money back my home!", translation: "发财！金币统统回我家！", timeSec: 4 },
  { text: "Google brothers Larry and Sergey search the golden dome,", translation: "谷歌兄弟搜索财富的尽头，", timeSec: 8 },
  { text: "All money back my home! All money back my home!", translation: "发财！金币统统回我家！", timeSec: 12 },
  { text: "Ballmer is yelling, developers dancing in foam,", translation: "鲍尔默疯狂怒吼，程序员狂喜高歌，", timeSec: 16 },
  { text: "All money back my home! All money back my home!", translation: "发财！金币统统回我家！", timeSec: 20 },
  { text: "Bill Gates turns blue screens to golden gates,", translation: "经典蓝屏一碎，金币铺天盖地，", timeSec: 24 },
  { text: "All money back my home! All money back my home!", translation: "发财！金币统统回我家！", timeSec: 28 },
  { text: "Buffett drinks Pepsi, counting his compounding states,", translation: "巴老太师喝起可乐，财富滚滚如潮，", timeSec: 32 },
  { text: "All money back my home! All money back my home!", translation: "发财！金币统统回我家！", timeSec: 36 },
  { text: "Ellison dumps databases full of shiny gold plates,", translation: "埃里森开启云端，倾倒千吨金砖，", timeSec: 40 },
  { text: "All money back my home! All money back my home!", translation: "发财！金币统统回我家！", timeSec: 44 },
  { text: "Zuck is in the Metaverse buying some virtual estates,", translation: "小扎在元宇宙戴上眼镜，漫天都是狗狗币，", timeSec: 48 },
  { text: "All money back my home! All money back my home!", translation: "发财！金币统统回我家！", timeSec: 52 },
  { text: "Bezos sends a parcel by a flying drone platoon,", translation: "贝老大快递空投，千万金币从天而降，", timeSec: 56 },
  { text: "All money back my home! All money back my home!", translation: "发财！金币统统回我家！", timeSec: 60 },
  { text: "Arnault wraps LVMH in champagne to the moon,", translation: "阿尔诺开启名包拉链，闪烁绚丽香槟，", timeSec: 64 },
  { text: "All money back my home! All money back my home!", translation: "发财！金币统统回我家！", timeSec: 68 },
  { text: "And Elon Musk is blasting Falcon Heavy to the stars!", translation: "马斯克载满特斯拉，一飞冲天到火星！", timeSec: 72 },
  { text: "ALL MONEY BACK MY HOME! Hallelujah golden rain!", translation: "发财！金币洒满人间！哈利路亚发大财！", timeSec: 76 }
];
